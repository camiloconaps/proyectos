<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

<!------ Include the above in your HEAD tag ---------->
<script src="assets/js/main.js"></script>
<link rel="stylesheet" href="assets/css/main.css">
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <title>Demanda Genesys</title>
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    
</head>

<body>

    
    <?php include('app/pages/home/menu.html'); ?>
    <div class="main-content">
        <?php include('app/pages/home/navbar.html'); ?>
        <main >
            <div id="mainHeader"></div>
            <!--Tabla-->
            <div class="recent-grid" id="mainContent">
                <div class="projects" id="tablero1">
                    
                </div>

                <div class="customers" id="tablero3">

                <div class="customers" id="tablero2">

                    
                </div>
                
            </div>
        </main>

    </div>

</body>

</html>